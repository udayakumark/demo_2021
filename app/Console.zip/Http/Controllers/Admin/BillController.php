<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Response;
use App\Models\ProductCategories;
use App\Models\Products;
use App\Models\InvoiceSettings;
use App\Models\TblSales;
use App\Models\SalesItem;
use App\Models\UserDetails;
use App\helpers;
use Validator;
use Illuminate\Support\Facades\Auth;

class BillController extends Controller
{

    public function Index()
    {
        $user  = User::select('users.*');
        $user->join('user_details', 'user_details.user_id', '=', 'users.id');
        $user->where('users.status','!=',0);
        $user->where('users.user_type',3);
        $user->orderBy('users.date_time', 'desc');
        $totalRecords 	= count($user->get());
        $data    		= $user->get();

        $productList  = Products::where('status', 1)->get();

        $categoryList = ProductCategories::where('status', 1)->orderBy('category_name')->get();

        $result = array();

        if(!empty($data)){
            foreach ($data as $index=>$vendors) {
                $result[$index]['first_name'] = $vendors->userDetails->first_name;
                $result[$index]['last_name'] = $vendors->userDetails->last_name;
                $result[$index]['id'] = $vendors->id;
            }
        }

        return view('admin.Bill.index',['vendorlist'=>$result,'categoryList'=>$categoryList,'productList'=>$productList]);
    }


    public function bill_print(Request $request){

        $bill_id 	= $request->bill_id;

        $inv_details  = TblSales::where('bill_id', $bill_id)->where('delete_flag',0)->first();

        $dealer_details =  UserDetails::where('user_id', $inv_details['dealer_id'])->first();

        $salesitems = SalesItem::where('bill_id', $bill_id)->get();

        return view('admin.Bill.invoicepdf',['vendorlist'=>$dealer_details,'inv_details'=>$inv_details,'salesitems'=>$salesitems]);
    }

    public function bill_add(Request $request){



        $validator = Validator::make($request->all(), [
            'supplname' => 'required',
            'billdate' => 'required',
            'total' => 'required',
        ]);

        if($validator->passes())
        {

            $inv_no  = InvoiceSettings::where('status', 1)->where('type','admin')->first();
            if(!empty($inv_no))
            {
                $inv_no1 = $inv_no['inv_no'];
                $total_amount 	= $request->total_amount;
                $billdate 	= $request->billdate;
                $supplname 	= $request->supplname;
                $product_category 	= $request->product_category;
                $product_id 	= $request->product_id;
                $qty 	= $request->qty;
                $Qtl 	= $request->qtlqty;
                $salesprice 	= $request->salesprice;
                $total 	= $request->total;
                $sub_total 	= $request->sub_total;
                $total_amount 	= $request->total_amount;
                $loginId  = Auth::guard('admin')->user()->id;

                $model    			  = new TblSales;
                $model->invoice_no    = $inv_no1;
                $model->inv_date    = $billdate;
                $model->dealer_id    = $supplname;
                $model->user_id      = $loginId;
                $model->sub_total       = $sub_total;
                $model->status       = 1;
                $model->delete_flag     = 0;
                $model->save();

                for($i=0;$i<count($product_id);$i++){
                    if($product_id[$i] != '0' && $product_id[$i] != 0){

                        $SalesItem    			  = new SalesItem;
                        $SalesItem->bill_id    = $model->bill_id;
                        $SalesItem->product_id    = $product_id[$i];
                        $SalesItem->Qtl    = $Qtl[$i];
                        $SalesItem->qty    = $qty[$i];
                        $SalesItem->price      = $salesprice[$i];
                        $SalesItem->total       = $total[$i];
                        $SalesItem->save();

                    }
                }

                $inv_no->inv_no = $inv_no1+1;
                $inv_no->save();

                if ($model){
                    header("Location: https://theaaura.com/fpdf/tutorial/tuto2.php?bill_id=".$model->bill_id);
                }

            }
        }
        else
        {
            return response()->json(['error'=>$validator->errors()->all()]);
        }
    }
}
