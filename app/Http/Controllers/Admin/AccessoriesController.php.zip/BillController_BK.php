<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Response;
use App\Models\Rice;
use App\Models\Bag;
use App\Models\TblBill;
use App\Models\InvoicenoSettings;
use App\Models\BillsItem;
use App\Models\UserDetails;
use App\Models\Warehouses;
use App\Models\Cashbook;
use App\helpers;
use Validator;
use Redirect;
use PDF;
use Illuminate\Support\Facades\Auth;

class BillController extends Controller
{
	public function B2bIndex()
    {
        return view('admin.Bill.b2b.List');
    }
	public function B2bList(Request $request)
    {
        $start 	= $request->start;
        $length = $request->length;
        $model  = TblBill::select('tbl_billing.*');
		$model->join('users', 'users.id', '=', 'tbl_billing.user_id');
        $model->join('user_details', 'user_details.user_id', '=', 'tbl_billing.vendor_id');
        $model->where('users.status','!=',0);
        $model->where('users.user_type',4);
        $model->where('users.type',2);
        $model = TblBill::where('tbl_billing.bill_type_id',9)->where('delete_flag',0)->where('status',1);
		// Filters Parameters
        parse_str($_POST['formData'], $filterArray);
		$invoice_no = "";
		if(isset($filterArray['invoice_no'])){
            $invoice_no = trim($filterArray['invoice_no']);
        }
		if($invoice_no!=""){
            $model->where('tbl_billing.invoice_no','like','%'.$invoice_no.'%');
        }
        $model->orderBy('tbl_billing.created_at', 'desc');
        $totalRecords 	= count($model->get());
        $data    		= $model->offset($start)->limit($length)->get();
        $result = [];
        if(!empty($data)){
            foreach ($data as $index=>$user) {
                $invoiceno    	= $user->invoice_no;
				$vendorname 		= "";
				$vendor_balance  	= "";
                $total_amount 	= $user->total;
				$invoicedate 		= "";
                if(isset($user->vendor_id)){
                    $UserDetails 	= UserDetails::where('user_id',$user->vendor_id)->first();
                    $vendorname = $UserDetails->first_name.' '.$UserDetails->last_name;
                    $vendor_balance = $UserDetails->current_balance;
                }
				if(isset($user->inv_date) && $user->inv_date!="")
                {
                    $invoicedate = date('d-m-Y',strtotime($user->inv_date));
                }
                $result[$index]['snumber'] = $start+1;
				$result[$index]['invoiceno'] = $invoiceno;
				$result[$index]['vendorname'] = $vendorname;
                $result[$index]['vendor_balance'] = $vendor_balance;
                $result[$index]['amount'] = $total_amount;
				$result[$index]['invoicedate'] = $invoicedate;
                // action buttons
                $action = '<a href="'.url('/admin/b2b/bill-print/'.$user->bill_id).'" title="Print" class="btn btn-icon btn-sm btn-primary update-button" target="_blank"><i class="fas fa-file-pdf"></i></a>&nbsp;&nbsp;<a href="'.url('/admin/b2b/bill-view/'.$user->bill_id).'" title="View" class="btn btn-icon btn-sm btn-info update-button"><i class="fas fa-eye"></i></a>&nbsp;&nbsp;<a href="'.url('/admin/b2b/bill-edit/'.$user->bill_id).'" title="View" class="btn btn-icon btn-sm btn-warning update-button"><i class="fas fas fa-edit"></i></a>&nbsp;&nbsp;<button title="Delete" data-id="'.$user->bill_id.'"   data-url="'.url('/admin/b2b-delete/').'"class="btn btn-icon btn-sm btn-danger delete-button"><i class="fas fa-trash"></i></button>';
                $result[$index]['action'] = $action;
                $start++;
            }
        }
        $response = array(
            "draw" => intval($request->draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $result
        );
        return response()->json($response);
    }
	public function B2bAdd(Request $request) {
		$actionUrl    = 'b2b/bill/add/';
		$redirectUrl  = '/admin/b2b/bill';
		$bill_type ='B2b';
		$bill_type_id =9;
		$bill_action ='Add';
        $user  = User::select('users.*');
        $user->join('user_details', 'user_details.user_id', '=', 'users.id');
        $user->where('users.status','!=',0);
        $user->where('users.user_type',4);
        $user->where('users.type',1);
        $user->where('user_details.account',$bill_type_id);
        $user->orderBy('users.date_time', 'desc');
        $totalRecords 	= count($user->get());
        $data    		= $user->get();
		$riceList  = Rice::where('status', 1)->get();
        $warehouseList  = Warehouses::where('status', 1)->get();
		$nextInvoiceId = $this->getInvoiceNo(9,'B2B');
        $result = array();
        if(!empty($data)){
            foreach ($data as $index=>$vendors) {
                $result[$index]['first_name'] = $vendors->userDetails->first_name;
                $result[$index]['last_name'] = $vendors->userDetails->last_name;
                $result[$index]['id'] = $vendors->id;
            }
        }
		$result2=array();
		$bag_type='';
        if(!empty($riceList)){
            foreach ($riceList as $index=>$rice) {
				if(isset($rice->bag_type)){
                    $b2bDetails 	= Bag::where('id',$rice->bag_type)->first();
                    $bag_type = $b2bDetails->name;
				}
				$riceB2bName = ($bag_type) ? $rice->original_name.' '.$bag_type : $rice->original_name;
                $result2[$index]['name'] = $riceB2bName;
                $result2[$index]['id'] = $rice->id;
            }
        }
		if(isset($_POST['_token']))
        {
			$validator = Validator::make($request->all(), [
            'supplname' => 'required',
            'billdate' => 'required',
            'total' => 'required',
            'invoice_no' => 'required',
            'warehouse' => 'required'
			]);

			if($validator->passes())
			{
				$inv_no1 = $request->invoice_no;
				$billdate 	= $request->billdate;
				$supplname 	= $request->supplname;
				$warehouse_id 	= $request->warehouse;
				$hsn   = $request->hsn;
				$product_id 	= $request->product_id;
				$qty 	= $request->qty;
				$price 	= $request->price;
				$final_price 	= $request->final_price;
				$total 	= $request->total;
				$sub_total 	= $request->sub_total;
				$discount 	= $request->discount;
				$total_amount 	= $request->total_amount;
				$loginId  = Auth::guard('admin')->user()->id;

				$model    			  = new TblBill;
				$model->bill_type_id = $bill_type_id;
				$model->invoice_no    = $inv_no1;
				$model->inv_date    = $billdate;
				$model->vendor_id    = $supplname;
				$model->user_id      = $loginId;
				$model->warehouse_id  = $warehouse_id;
				$model->hsn   		  = $hsn;
				$model->discount   = $discount;
				$model->sub_total   = $sub_total;
				$model->total       = $total_amount;
				$model->status      = 1;
				$model->delete_flag = 0;
				$model->save();
				if($model->save())
				{
					for($i=0;$i<count($product_id);$i++){
						if($product_id[$i] != '0' && $product_id[$i] != 0){

							$SalesItem    			 = new BillsItem;
							$SalesItem->bill_id  = $model->bill_id;
							$SalesItem->paddy_id    = $product_id[$i];
							$SalesItem->qty    = $qty[$i];
							$SalesItem->price    = $price[$i];
							$SalesItem->final_price    = $final_price[$i];
							$SalesItem->total       = $total[$i];
							$SalesItem->save();
						}
					}
					if ($model && $SalesItem){
						return response()->json(['success'=>'B2b Bill Details Created Successfully.']);
					} else {
						return response()->json(['singleerror'=>'Failed to Create B2b Bill information. Try again after sometime.']);
					}
				} else {
					return response()->json(['singleerror'=>'Failed to Create B2b Bill information. Try again after sometime.']);
				}
			}
			else {
				return response()->json(['error'=>$validator->errors()->all()]);
			}
		}
		$inv_details = array('invoice_no'=>$nextInvoiceId,'inv_date'=>date('Y-m-d'),'vendor_id'=>$request->supplname,'warehouse_id'=>$request->warehouse,'hsn'=>$request->hsn,'discount'=>$request->discount,'sub_total'=>$request->sub_total,'total'=>$request->total);
		$vendor_details = array('current_balance'=>$request->balance,'address'=>$request->address);
		$salesitems = array(array("id"=>'',"bill_id"=>'',"paddy_id"=>'',"qty"=>'',"price"=>'',"final_price"=>'',"total"=>''));
        return view('admin.Bill.b2b.index',['warehouseList'=>$warehouseList,'vendorlist'=>$result,'riceList'=>$result2,'inv_details'=>$inv_details,'vendor_details'=>$vendor_details,'salesitems'=>$salesitems,'actionUrl'=>$actionUrl,'bill_type'=>$bill_type,'bill_action'=>$bill_action,'redirectUrl'=>$redirectUrl,'nextInvoiceId'=>$nextInvoiceId]);
    }
	public function B2bView(Request $request){
        $bill_id 	= $request->bill_id;
		$bill_type ='B2b';
		$bill_type_id =9;
		$bill_action ='View';
     
        $inv_details  = TblBill::where('bill_id', $bill_id)->where('delete_flag',0)->first();
		$warehouseListGet  = Warehouses::where('status', 1)->where('id', $inv_details['warehouse_id'])->first();
        $vendor_details =  UserDetails::where('user_id', $inv_details['vendor_id'])->first();
        $salesitems = BillsItem::where('bill_id', $bill_id)->get();
		$riceList  = Rice::where('status', 1)->get();
		if(isset($warehouseListGet['name']) && $warehouseListGet['name']!="") {
			$warehouseList  = $warehouseListGet['name'];
		}
		$result=array();
		$bag_type ='';
        if(!empty($riceList)){
            foreach ($riceList as $index=>$rice) {
				if(isset($rice->bag_type)){
                    $b2bDetails 	= Bag::where('id',$rice->bag_type)->first();
                    $bag_type = $b2bDetails->name;
				}
				$riceB2bName = ($bag_type) ? $rice->original_name.' '.$bag_type : $rice->original_name;
                $result[$index]['name'] = $riceB2bName;
                $result[$index]['id'] = $rice->id;
            }
        }
		return view('admin.Bill.b2b.view',['vendorlist'=>'','vendor_details'=>$vendor_details,'riceList'=>$result,'warehouseList'=>$warehouseList,'inv_details'=>$inv_details,'salesitems'=>$salesitems,'bill_type'=>$bill_type,'bill_action'=>$bill_action]); 
    }
	public function B2bEdit(Request $request) {
		$bill_id 	= $request->bill_id;
		$actionUrl    = 'admin/b2b/bill-edit/'.$bill_id;
		$redirectUrl  = '/admin/b2b/bill';
		$bill_type ='B2b';
		$bill_type_id =9;
		$bill_action ='Edit';
        $user  = User::select('users.*');
        $user->join('user_details', 'user_details.user_id', '=', 'users.id');
        $user->where('users.status','!=',0);
        $user->where('users.user_type',4);
        $user->where('users.type',1);
        $user->where('user_details.account',$bill_type_id);
        $user->orderBy('users.date_time', 'desc');
        $totalRecords 	= count($user->get());
        $data    		= $user->get();
		$warehouseList  = Warehouses::where('status', 1)->get();
		$inv_details  = TblBill::where('bill_id', $bill_id)->where('delete_flag',0)->first();
        $vendor_details =  UserDetails::where('user_id', $inv_details['vendor_id'])->first();
        $salesitems = BillsItem::where('bill_id', $bill_id)->get();
		$riceList  = Rice::where('status', 1)->get();
		$nextInvoiceId = $this->getInvoiceNo(9,'B2B');
        $result = array();
        if(!empty($data)){
            foreach ($data as $index=>$vendors) {
                $result[$index]['first_name'] = $vendors->userDetails->first_name;
                $result[$index]['last_name'] = $vendors->userDetails->last_name;
                $result[$index]['id'] = $vendors->id;
            }
        }
		$result2=array();
		$bag_type='';
        if(!empty($riceList)){
            foreach ($riceList as $index=>$rice) {
				if(isset($rice->bag_type)){
                    $b2bDetails 	= Bag::where('id',$rice->bag_type)->first();
                    $bag_type = $b2bDetails->name;
				}
				$riceB2bName = ($bag_type) ? $rice->original_name.' '.$bag_type : $rice->original_name;
                $result2[$index]['name'] = $riceB2bName;
                $result2[$index]['id'] = $rice->id;
            }
        }
		if(isset($_POST['_token']))
        {
			$validator = Validator::make($request->all(), [
            'supplname' => 'required',
            'billdate' => 'required',
            'total' => 'required',
            'invoice_no' => 'required',
            'warehouse' => 'required'
			]);

			if($validator->passes())
			{
				$invoice_type = $request->invoice_type;
				$inv_no1 = $request->invoice_no;
				$billdate 	= $request->billdate;
				$supplname 	= $request->supplname;
				$warehouse_id 	= $request->warehouse;
				$hsn   = $request->hsn;
				$product_id 	= $request->product_id;
				$qty 	= $request->qty;
				$price 	= $request->price;
				$final_price 	= $request->final_price;
				$total 	= $request->total;
				$sub_total 	= $request->sub_total;
				$discount 	= $request->discount;
				$total_amount 	= $request->total_amount;
				$loginId  = Auth::guard('admin')->user()->id;

				$model  = TblBill::where('bill_id',$bill_id)->first();
				$model->bill_type_id = $bill_type_id;
				$model->invoice_no    = $inv_no1;
				$model->inv_date    = $billdate;
				$model->vendor_id    = $supplname;
				$model->user_id      = $loginId;
				$model->warehouse_id  = $warehouse_id;
				$model->hsn   		  = $hsn;
				$model->discount   = $discount;
				$model->sub_total   = $sub_total;
				$model->total       = $total_amount;
				$model->status      = 1;
				$model->delete_flag = 0;
				$model->save();
				if($model->save())
				{
					$salesitems = BillsItem::where('bill_id', $bill_id)->get();					
					if(isset($salesitems) && !empty($salesitems)) {
	 					foreach($salesitems as $salesitem) {
							BillsItem::where('id', $salesitem->id)->delete();
						}
					}
					for($i=0;$i<count($product_id);$i++){
						if($product_id[$i] != '0' && $product_id[$i] != 0){

							$SalesItem    			 = new BillsItem;
							$SalesItem->bill_id  = $model->bill_id;
							$SalesItem->paddy_id    = $product_id[$i];
							$SalesItem->qty    = $qty[$i];
							$SalesItem->price    = $price[$i];
							$SalesItem->final_price    = $final_price[$i];
							$SalesItem->total       = $total[$i];
							$SalesItem->save();
						}
					}
					if ($model && $SalesItem){
						return response()->json(['success'=>'B2b Bill Details Updated Successfully.']);
	 				} else {
	 					return response()->json(['singleerror'=>'Failed to Update B2b Bill information. Try again after sometime.']);
					}
	 			} else {
	 				return response()->json(['singleerror'=>'Failed to Updat B2b Bill information. Try again after sometime.']);
	 			}
			}
			else {
				return response()->json(['error'=>$validator->errors()->all()]);
			}
		}
        return view('admin.Bill.b2b.index',['warehouseList'=>$warehouseList,'vendorlist'=>$result,'riceList'=>$result2,'inv_details'=>$inv_details,'vendor_details'=>$vendor_details,'salesitems'=>$salesitems,'actionUrl'=>$actionUrl,'bill_type'=>$bill_type,'bill_action'=>$bill_action,'redirectUrl'=>$redirectUrl,'nextInvoiceId'=>$nextInvoiceId]);
    }
	// Delete
    public function B2bDelete(Request $request) {
        $id 		= isset($request->dealerId) ? $request->dealerId : 0;
        $model      = TblBill::where('bill_id', $id)->first();
        if(!empty($model))
        { 
             $model->status       = 0;
             $model->save();
            return response()->json(['success'=>'B2b Details Deleted Successfully.']);
        } 
        else
        {
            return response()->json(['error'=>'Invalid Request. Try Again.']);
        }
    }
	public function getVendordetailsb2b(Request $request) {
        $user_id 	= $request->user_id;
        $vendor_details =  UserDetails::where('user_id', $user_id)->first();
        $cashdetails = $vendor_details->cashbook->sum('amount');
        $crcash = Cashbook::where('user_id', $user_id)->where('type', 'CR')->sum('amount');
        $dbcash = Cashbook::where('user_id', $user_id)->where('type', 'DB')->sum('amount');
        $balance = $crcash - $dbcash;
        if ($balance > 0){
            $balance = "+".$balance;
        }
        $response = array(
            "vendor_details" => $vendor_details,
            "cashdetails" => $balance
        );
        return response()->json($response);
    }
	public function getRicedetailsb2b(Request $request) {
        $riceList  = Rice::where('status', 1)->where('id',$request->rice_id)->first();
		echo $riceList->dealers_price;
        //return response()->json($response);
    }
	public function getInvoiceNo($type,$sourceType) {
		$InvoicenoSettings = InvoicenoSettings::where('type', $type)->value('invoice_no');
		$billMaxId = TblBill::where('invoice_no', 'like', '%SAK_'.$sourceType.'%')->orderBy('bill_id', 'desc')->value('invoice_no');
		$nextInvoiceId='';
		if(isset($billMaxId) && $billMaxId!='') {
			$invoicePrefix = "SAK_".$sourceType."_2021_";
			$billMaxIdPrefix = ltrim(str_replace($invoicePrefix, "", $billMaxId),"0");	
			$nextInvoiceIdVal = $billMaxIdPrefix+1;
			$nextInvoiceId = $invoicePrefix.STR_PAD((string)$nextInvoiceIdVal,5,"0",STR_PAD_LEFT);
		} else {
			$nextInvoiceId = $InvoicenoSettings;
		}
		return $nextInvoiceId;
	}
	public function B2bPrint(Request $request){
        $bill_id 	= $request->bill_id;
        $inv_details  = TblBill::where('bill_id', $bill_id)->where('delete_flag',0)->first();
        $dealer_details =  UserDetails::where('user_id', $inv_details['dealer_id'])->first();
        $salesitems = BillsItem::where('bill_id', $bill_id)->get();
		$data = [];
		$pdf = PDF::loadView('admin.Bill.b2b.invoicepdf', $data);
		return $pdf->stream('document.pdf');
        //return view('admin.Bill.b2b.invoicepdf',['vendorlist'=>$dealer_details,'inv_details'=>$inv_details,'salesitems'=>$salesitems]);
    }
}
