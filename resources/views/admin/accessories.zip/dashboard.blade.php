@extends('layouts.admin-layout')
@section('title', 'Dashboard')
@section('content')
<div class="main-content">
  <section class="section">
    <div class="row">
      <div class="col-12 col-sm-12 col-lg-12">
        <div class="card">
          <div class="card-header">
            <h4>Welcome to Dashboard</h4>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
@endsection   